# Accessibility, Security, Performance and TypeScript Rules

## 1. Accessibility

Accessibility is mandatory.

Use:

- Semantic HTML
- Proper headings
- Labels
- Keyboard navigation
- Visible focus
- Accessible names
- Correct ARIA only when necessary
- Existing accessible shadcn/Radix components

Never use a clickable `div` when a semantic element is appropriate.

Icon-only buttons MUST have an accessible label.

Dialogs, dropdowns, popovers, selects and similar controls should use existing accessible primitives.

## 2. TypeScript

TypeScript strictness is mandatory.

Rules:

- No `any` unless there is an explicitly documented unavoidable external boundary.
- Prefer `unknown` and narrow it.
- Properly type props.
- Properly type API responses.
- Use discriminated unions for complex state.
- Avoid unnecessary type assertions.
- Do not use `@ts-ignore` to hide errors.
- Do not use `@ts-expect-error` without a genuine reason and explanation.
- Keep feature-specific types close to the feature.

## 3. Security

Never:

- Put secrets in frontend code.
- Put private API keys in browser-exposed environment variables.
- Trust client-side authorization alone.
- Render unsanitized HTML.
- Construct unsafe URLs from untrusted input.
- Log passwords, tokens, or sensitive information.

Authorization must ultimately be enforced server-side.

The UI should additionally hide/disable actions according to the existing permission model.

## 4. Performance

Do not optimize blindly.

First eliminate structural problems:

1. Unnecessary renders
2. Unnecessary Effects
3. Duplicate API requests
4. Excessive data loading
5. Large unnecessary bundles
6. Huge lists without pagination/virtualization

Use:

- Route-level lazy loading where supported
- Pagination for large datasets
- Virtualization for genuinely large lists
- Debouncing for expensive search/filter operations
- Appropriate caching
- Stable keys

Do not automatically add:

```tsx
useMemo()
useCallback()
React.memo()
```

Use them when there is a demonstrated or architectural reason.

## 5. Error Boundaries and Resilience

Use the application's existing Error Boundary strategy around major feature/route boundaries.

Never silently swallow errors.

Provide:

- User-friendly error message
- Retry where appropriate
- Logging/telemetry through existing mechanisms

Do not expose raw backend exceptions to users.
