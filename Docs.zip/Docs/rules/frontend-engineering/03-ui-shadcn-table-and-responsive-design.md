# UI, shadcn and Table Rules

## 1. Use the Existing Design System

Follow the application's existing styling system.

If Tailwind/shadcn is already used:

- Reuse existing design tokens.
- Reuse existing component variants.
- Use `cn()` where appropriate.
- Do not hardcode colors when semantic tokens exist.
- Do not introduce another styling framework.
- Do not duplicate button/input/dialog/table styles.
- Preserve dark-mode behavior if supported.
- Preserve focus states.
- Follow existing spacing and typography conventions.

## 2. Table Requirement — Mandatory

### DO NOT USE TANSTACK TABLE

New screens MUST NOT introduce or use:

```text
@tanstack/react-table
```

Do not import:

```tsx
import { useReactTable } from "@tanstack/react-table";
```

Do not add TanStack Table as a new dependency.

Do not create a second table framework.

## 3. Use the Provided shadcn Table Reference

The attached `tablecn-main.zip` is the reference for the desired table UI and interaction patterns.

The AI MUST inspect and reuse the relevant shadcn Table primitives/patterns from the provided implementation rather than inventing an unrelated table UI.

Important: if the provided ZIP contains an advanced `DataTable` implementation that depends on TanStack Table, DO NOT copy its TanStack-specific implementation.

Use the ZIP as a reference for:

- Visual structure
- Header/row/cell patterns
- Toolbar behavior
- Pagination UX
- Selection UX
- Filtering UX
- Responsive behavior
- Empty/loading presentation
- Table composition

But implement the required behavior using the application's shadcn Table primitives and existing state/API mechanisms.

### Absolute rule

```text
Use shadcn Table.
Do NOT use TanStack Table.
Do NOT add another table library.
```

## 4. Table Behavior

Implement only functionality required by the screen:

- Column headers
- Sorting
- Filtering
- Search
- Pagination
- Row selection
- Row actions
- Column visibility
- Empty state
- Loading state
- Error state
- Responsive behavior

Do not implement advanced functionality merely because the reference implementation supports it.

## 5. Table Accessibility

Use semantic table elements:

```tsx
<Table>
  <TableHeader>
  <TableBody>
  <TableRow>
  <TableHead>
  <TableCell>
```

Do not build tables from arbitrary `div` elements.

Interactive table controls must have accessible names.

## 6. Responsive Design

Every new screen MUST work at:

- Mobile
- Tablet
- Desktop
- Large desktop

Check:

- Side menu behavior
- Page header
- Toolbar wrapping
- Table overflow
- Dialog dimensions
- Forms
- Buttons
- Long text
- Empty states

Prefer responsive layouts over fixed-width layouts.
