# Definition of Done

A new React screen is NOT complete until all applicable requirements are satisfied.

## Architecture

- [ ] Existing application patterns were inspected first.
- [ ] Closest existing screen was identified.
- [ ] Existing components/hooks/utilities were reused.
- [ ] No duplicate shared component was created.
- [ ] Route was added using the existing routing architecture.
- [ ] Side menu entry was added.
- [ ] Active navigation state works.
- [ ] Authorization/permissions are respected.

## UI

- [ ] Screen follows the existing application layout.
- [ ] Page header is implemented.
- [ ] Responsive behavior works.
- [ ] Loading state exists.
- [ ] Empty state exists.
- [ ] Error state exists.
- [ ] Success/populated state exists.
- [ ] Disabled/read-only states are handled where applicable.

## Table

- [ ] Existing shadcn Table implementation/pattern was inspected.
- [ ] shadcn Table primitives/patterns are used.
- [ ] `@tanstack/react-table` was NOT introduced.
- [ ] No second table library was introduced.
- [ ] Table is accessible.
- [ ] Required sorting/filtering/pagination works.
- [ ] Row actions are accessible.
- [ ] Large datasets are handled appropriately.

## Code Quality

- [ ] TypeScript is fully typed.
- [ ] No unnecessary `any`.
- [ ] No unnecessary Effects.
- [ ] No duplicated/derived state.
- [ ] No dead code.
- [ ] No debugging `console.log`.
- [ ] No unnecessary dependencies.
- [ ] Existing design tokens/components are reused.
- [ ] No unrelated refactoring was introduced.

## Accessibility

- [ ] Semantic HTML is used.
- [ ] Forms have labels.
- [ ] Keyboard navigation works.
- [ ] Focus states are visible.
- [ ] Icon-only controls have accessible names.
- [ ] Dialogs/dropdowns/popovers are accessible.
- [ ] Color is not the only indicator of state.
- [ ] Reduced-motion behavior is respected where applicable.

## Testing

- [ ] Unit/integration tests added where appropriate.
- [ ] Main user interactions are tested.
- [ ] Loading/error/empty behavior is tested.
- [ ] Validation is tested.
- [ ] Permission behavior is tested where applicable.
- [ ] Playwright navigation test exists.
- [ ] Playwright direct-route test exists.
- [ ] Playwright primary workflow test exists.
- [ ] Playwright error/empty scenario exists where applicable.
- [ ] Tests use accessible/user-facing selectors.
- [ ] No arbitrary `waitForTimeout()` calls.

## Verification

- [ ] Type-check passes.
- [ ] Lint passes.
- [ ] Unit/integration tests pass.
- [ ] Playwright tests pass.
- [ ] Production build passes.
- [ ] No unrelated existing functionality was broken.

## Final AI Report

After implementation, report:

### Files Changed

List created and modified files.

### Screen

Report:

- Route
- Side menu entry
- Main functionality

### API

Report API/service changes.

### Testing

Report:

- Unit/integration tests
- Playwright tests
- Scenarios covered

### Verification

Report:

- Type-check
- Lint
- Unit tests
- Playwright
- Production build

### Open Items

Clearly identify anything that could not be completed.

Never claim a test passed if it was not actually executed.
