# React New Screen Engineering Rules

## Purpose

These rules define the mandatory engineering standards for AI agents creating new React screens in the existing application.

The AI must produce production-ready screens that are:

- Consistent with the existing application
- Reusable and maintainable
- Accessible
- Responsive
- Fully typed
- Secure
- Performant
- Tested
- Integrated with the existing side menu and routing
- Covered by appropriate unit/integration tests
- Covered by Playwright end-to-end tests for user-facing workflows

## Priority

When rules conflict, follow this order:

1. Correctness
2. Existing application architecture and conventions
3. Security
4. Accessibility
5. Maintainability
6. Testability
7. Performance
8. Brevity

Do not sacrifice correctness or maintainability merely to reduce code.

## Golden Rule

> Do not build a new React screen from scratch when the application already contains the pattern.

Inspect. Reuse. Compose. Implement. Test. Verify.

The new screen should look, behave, navigate, validate, fail, recover, and test like a native part of the existing application.
