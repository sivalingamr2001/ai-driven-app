# State, Data, API and Form Rules

## 1. State Management

Use the simplest appropriate state mechanism.

Decision order:

1. Derive the value during render.
2. URL/query state for shareable/navigable state.
3. Local `useState` for local UI state.
4. `useReducer` for complex related transitions.
5. Existing application context for tree-wide state.
6. Existing external state solution when appropriate.
7. Existing server-state solution for remote data.

Rules:

- Never store values that can be derived.
- Store IDs rather than duplicated selected objects when appropriate.
- Use updater functions when new state depends on previous state.
- Keep state close to where it is used.
- Do not introduce global state for a single screen.
- Do not duplicate server state into local state without a clear reason.

## 2. useEffect

Use Effects only when synchronizing with an external system.

Good examples:

- Browser APIs
- Event listeners
- Timers
- WebSocket/subscriptions
- Third-party widgets
- External integrations

Do NOT use `useEffect` merely to:

- Calculate derived values
- Filter or transform data
- Synchronize React state to another React state
- Respond to button clicks
- Notify a parent when an event handler can do it directly

Every Effect MUST:

- Have correct dependencies.
- Clean up subscriptions/listeners/timers.
- Avoid stale closures.
- Avoid unnecessary state updates.

Never disable `react-hooks/exhaustive-deps` just to make lint pass.

## 3. API and Data Fetching

Use the application's existing API/service architecture.

Prefer:

```text
Component
   ↓
Hook
   ↓
Service/API
   ↓
Backend
```

Requirements:

- Centralize API calls where the application already does so.
- Strongly type request and response models.
- Validate untrusted external data where appropriate.
- Handle loading.
- Handle errors.
- Handle empty responses.
- Handle unauthorized responses.
- Handle expired authentication using existing auth behavior.
- Avoid duplicate requests.
- Cancel obsolete requests where applicable.
- Never expose secrets in frontend code.

## 4. Loading, Empty, Error and Success

Every data-driven screen MUST explicitly handle:

### Loading

Use the application's existing Skeleton/Spinner/loading component.

### Empty

Provide a meaningful message and, where appropriate, an action.

### Error

Provide:

- Clear error message
- Retry action when recoverable

### Success

Render the populated data.

### Disabled / Read-only

Respect permissions and business rules.

Never leave a blank screen while data is loading or has failed.

## 5. Forms

Use the application's existing form architecture.

If React Hook Form + Zod already exists, reuse it.

Rules:

- Define validation clearly.
- Client validation does not replace server validation.
- Show validation errors next to fields.
- Associate labels with controls.
- Prevent accidental double submission.
- Show submitting state.
- Preserve input appropriately.
- Handle API validation errors.
- Do not silently discard user input.
