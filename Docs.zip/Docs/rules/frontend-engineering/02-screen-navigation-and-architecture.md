# Screen, Navigation and Architecture Rules

## 1. Screen Architecture

A new screen should normally follow:

```text
Side Menu
   ↓
Route
   ↓
Page / Screen
   ↓
Feature Components
   ↓
Hooks / Services / API
   ↓
Shared UI Components
```

Keep business logic outside purely presentational components.

Prefer feature-oriented organization such as:

```text
features/
  orders/
    components/
    hooks/
    api/
    types/
    orders-page.tsx
    orders-page.test.tsx
```

Use the existing project structure if it differs.

## 2. Side Menu Integration

Every new user-facing screen that belongs in application navigation MUST be integrated into the existing side menu.

The AI must:

1. Find the existing side menu implementation.
2. Add the new menu item using the existing pattern.
3. Use the existing icon system.
4. Use the existing permission/visibility mechanism.
5. Use the existing route.
6. Ensure the active menu state works.
7. Ensure nested routes highlight the correct parent where applicable.
8. Ensure unauthorized users do not see or access protected screens.
9. Never create a second side menu implementation.

## 3. Routing

Every new screen MUST have a proper route.

Requirements:

- Use the application's existing router.
- Do not introduce another routing library.
- Follow existing route naming conventions.
- Protected screens must use existing authentication/authorization guards.
- Direct navigation to the URL must work.
- Browser refresh must work.
- Invalid routes must follow existing not-found behavior.
- Validate route/query parameters where necessary.

## 4. Page Layout

Follow the existing application layout.

A typical screen may contain:

```text
Page Layout
├── Side Menu
├── Main Content
│   ├── Breadcrumb / Navigation context
│   ├── Page Header
│   │   ├── Title
│   │   ├── Description
│   │   └── Primary Action
│   └── Content
│       ├── Filters / Toolbar
│       ├── Table / Form / Cards
│       └── Pagination / Actions
```

Do not create arbitrary layouts when an existing layout component is available.

## 5. Component Architecture

Each component should have one clear responsibility.

Prefer:

```text
OrdersPage
 ├── OrdersHeader
 ├── OrdersFilters
 ├── OrdersTable
 ├── OrdersPagination
 └── OrderDialog
```

over one large component containing unrelated logic.

- Extract components when logic becomes difficult to understand or test.
- Do not split components merely because they reach an arbitrary line count.
- Prefer composition over configuration-heavy components.
- Reuse shared components.

## 6. No Duplicate Components

Before creating a new component, search for existing:

- Button
- Dialog
- AlertDialog
- Input
- Select
- Dropdown
- Tooltip
- Tabs
- Table
- Pagination
- Form
- DatePicker
- PageHeader
- Breadcrumb
- EmptyState
- LoadingState
- ErrorState

If one exists, reuse it.

If it is almost correct, extend or compose it instead of creating a competing implementation.
