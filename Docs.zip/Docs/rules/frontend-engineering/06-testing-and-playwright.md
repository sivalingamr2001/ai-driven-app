# Testing and Playwright Rules

## 1. Automated Testing Is Mandatory

Every new feature must have appropriate automated tests.

Use the application's existing test stack.

Test behavior rather than implementation details.

Prioritize:

- Business logic
- Hooks
- Components with meaningful behavior
- Forms
- Validation
- Error handling
- Permissions
- Table behavior
- User interactions

Prefer:

```tsx
getByRole()
getByLabelText()
getByText()
```

over implementation-specific selectors.

Avoid testing:

- Internal state
- `setState` calls
- Private implementation details
- CSS classes unless visual behavior specifically requires it

## 2. Playwright E2E — REQUIRED

Every new user-facing screen MUST have Playwright E2E coverage.

A screen is not complete without Playwright coverage.

## 3. Minimum Playwright Coverage

### Navigation

Verify:

```text
Side Menu → New Screen
```

works.

### Direct URL

Navigate directly to the route and verify the screen loads.

### Main screen

Verify:

- Page heading
- Main content
- Primary controls
- Table/form/content

are visible.

### Primary workflow

Test the main business action, such as:

- Create
- Edit
- Delete
- Search
- Filter
- Change status
- Submit
- Export

### Error behavior

Verify the appropriate error state when the API fails.

### Empty behavior

Verify the empty state when no data exists.

### Permissions

If authorization applies, verify unauthorized users cannot perform protected actions.

## 4. Playwright Selectors

Prefer:

```tsx
getByRole()
getByLabel()
getByText()
```

Do not rely on random CSS classes.

Avoid arbitrary:

```tsx
page.waitForTimeout(5000)
```

Prefer deterministic assertions:

```tsx
await expect(element).toBeVisible();
await expect(element).toHaveText(...);
await expect(page).toHaveURL(...);
```

## 5. Playwright Test Organization

Organize E2E tests by feature:

```text
e2e/
  users/
    users-navigation.spec.ts
    users-list.spec.ts
    users-create.spec.ts
    users-edit.spec.ts
    users-permissions.spec.ts
```

For small features, a single spec file is acceptable.

Tests must be independent.

## 6. Test the User

Prefer:

```tsx
await page.getByRole("button", { name: "Create User" }).click();

await expect(
  page.getByRole("dialog", { name: "Create User" })
).toBeVisible();
```

over selectors tied to implementation classes.

## 7. Test Data

Use deterministic test data.

Do not depend on:

- Random production data
- Developer-specific accounts
- Uncontrolled timestamps
- External third-party services
- Unstable network responses

Reuse existing fixtures, mocks and test infrastructure.

## 8. Unit/Integration Coverage

Where appropriate, cover:

- Component rendering
- User interactions
- Validation
- Loading/error/empty behavior
- Business logic
- Permissions
- Table behavior

Do not write low-value tests merely to increase coverage.

Every bug fix should include a regression test when practical.
