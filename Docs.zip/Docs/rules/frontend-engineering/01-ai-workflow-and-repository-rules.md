# AI Workflow and Repository Rules

## 1. Inspect Before Coding

Before writing code, inspect:

- Existing application structure
- Existing side menu/navigation
- Existing routing configuration
- Existing screen/page implementations
- Existing layout components
- Existing shared UI components
- Existing table implementations
- Existing forms
- Existing API/service layer
- Existing hooks
- Authentication and authorization patterns
- Loading/error patterns
- Existing tests
- `package.json`
- TypeScript configuration
- ESLint/lint configuration
- Playwright configuration

Do not invent an architecture when the repository already has one.

## 2. Find the Closest Existing Screen

Find an existing screen closest to the requested functionality.

Reuse its:

- Layout
- Page header
- Side menu integration
- Breadcrumbs
- Filters
- Buttons
- Tables
- Dialogs
- Forms
- Loading states
- Error handling
- API patterns
- Test patterns

## 3. Identify Required Changes

Before implementation, determine:

- New route
- Side menu entry
- Page component
- Feature components
- API/service changes
- Types
- State
- Table requirements
- Forms
- Permissions
- Unit/integration tests
- Playwright scenarios

Do not create unnecessary abstractions.

## 4. Implement Incrementally

Implement in this order where applicable:

1. Route
2. Side menu/navigation
3. Page shell/layout
4. Page header
5. Main content
6. API/data integration
7. Table/forms/actions
8. Loading/empty/error states
9. Accessibility
10. Unit/integration tests
11. Playwright tests

## 5. Verify

Before considering the task complete, run:

- TypeScript type-check
- Lint
- Unit/integration tests
- Playwright tests
- Production build

Fix failures before reporting completion.

## 6. Never Invent

Do not invent:

- API endpoints
- API request/response properties
- Routes
- Permissions
- Component props
- Database fields
- Environment variables
- Authentication behavior
- Business rules

If required information cannot be determined from the repository, identify the missing information instead of guessing.

## 7. Preserve Existing Behavior

When modifying shared components:

- Search for usages first.
- Understand existing consumers.
- Update affected tests.
- Run the existing test suite.
- Prefer feature-local changes.
- Do not perform unrelated refactoring.

## 8. Dependencies

Do not install a new package unless:

1. Existing project capabilities cannot solve the problem.
2. The functionality genuinely requires it.
3. The dependency is compatible with the application.
4. The dependency is justified.

Never introduce a second table framework.
